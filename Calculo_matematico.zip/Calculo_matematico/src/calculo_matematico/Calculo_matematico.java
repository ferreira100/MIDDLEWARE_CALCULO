/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculo_matematico;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Gemeos
 */
public final class Calculo_matematico {
    
    public Calculo_matematico() throws IOException{
        server2_recebimento();
       
        
       
    }
    
    
     public void server2_recebimento() throws IOException {

        String valores;
            
 
            ServerSocket ss = new ServerSocket(4443);
            
            while (true) { //while usado para receber mensagens toda vez que o cliente mandar mensagens
                
                Socket s = ss.accept(); // ele aceita a mensagem e deixa outra em espera 
                Scanner leitor = new Scanner(s.getInputStream()); // String recebe o conteudo da linha
               
               while (leitor.hasNext()) { // while usado para pegar proxima linha
                    
                   valores = leitor.nextLine();
                  
                   
                    for (int i = 1; i < valores.length(); i++) {
                        if (valores.charAt(i) == '+') {
                            //System.out.println("s[" + i + "] = a");
                            //System.out.println("É adição");
                            envia_Servidor_Resultado(valores);
                           
                        }
                        if((valores.charAt(i) == 'x')){
                            
                              envia_Servidor1_Resultado(valores);;

                        }
                    }
                   
                }
                
                s.close();
            }
            
        
            
           
    }
     
      public void server1_recebimento() throws IOException {

        String valores1;
            
 
            ServerSocket ss1 = new ServerSocket(7777);
            
            while (true) { //while usado para receber mensagens toda vez que o cliente mandar mensagens
                
                Socket s1 = ss1.accept(); // ele aceita a mensagem e deixa outra em espera 
                Scanner leitor1 = new Scanner(s1.getInputStream()); // String recebe o conteudo da linha
               
               while (leitor1.hasNext()) { // while usado para pegar proxima linha
                    
                   valores1 = leitor1.nextLine();
                  
                   System.out.println("Resultado da Soma "+valores1);
                   
                   
                   
                }
                
                s1.close();
            }
            
           
    }
      
      
      
     
     
     public void envia_Servidor_Resultado(String resultado) throws IOException{
        
        
        Socket socket = null;

        String host = "127.0.0.1";

        socket = new Socket(host, 6666);
          
        PrintWriter escritor = new PrintWriter(socket.getOutputStream());

        escritor.println(resultado);
        escritor.flush();
        escritor.close();
        
        System.out.println("Resultado enviado para Server da Soma!");
            
         server1_recebimento();
            
        }
     
     public void envia_Servidor1_Resultado(String resultado) throws IOException{
        
        
        Socket socket = null;

        String host = "192.168.43.37";

        socket = new Socket(host, 1234);
          
        PrintWriter escritor = new PrintWriter(socket.getOutputStream());

        escritor.println(resultado);
        escritor.flush();
        escritor.close();
        
        System.out.println("Resultado enviado!");
             server1_recebimento();
            
        }
   
    public static void main(String[] args) throws IOException {
        
        new Calculo_matematico();
      
        
    }
    
    
    
}
