/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculo_matematico;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Gemeos
 */
public class Cliente {
    
    public Cliente() throws IOException{
        envia_Servidor_Resultado();
         server2_recebimento();
    }
    
     public void server2_recebimento() throws IOException {

        String valores;

            ServerSocket ss = new ServerSocket(7777);

            while (true) { //while usado para receber mensagens toda vez que o cliente mandar mensagens
                
                Socket s = ss.accept(); // ele aceita a mensagem e deixa outra em espera 
                Scanner leitor = new Scanner(s.getInputStream()); // String recebe o conteudo da linha

               while (leitor.hasNext()) { // while usado para pegar proxima linha
                    
                   valores = leitor.nextLine();
                   
                   System.out.println("Resultado Final: "+valores);
                   
                }
                
                s.close();
            }

    }
    
    
    public void envia_Servidor_Resultado() throws IOException{
        
        String resultado = "2 + 2";
        
        Socket socket = null;

        String host = "127.0.0.1";

        socket = new Socket(host, 5555);
          
        PrintWriter escritor = new PrintWriter(socket.getOutputStream());

        escritor.println(resultado);
        escritor.flush();
        escritor.close();
        
        System.out.println("Resultado enviado!");
            
            
        }
    
      public static void main(String[] args) throws IOException{
          new Cliente();
      }
    
}
