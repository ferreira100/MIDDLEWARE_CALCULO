/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculo_matematico;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Gemeos
 */
public class Server1 {
    
    
     public Server1() throws IOException{
        server2_recebimento();
        
    }
    
     public void server2_recebimento() throws IOException {

        String valores;

            ServerSocket ss = new ServerSocket(6666);

            while (true) { //while usado para receber mensagens toda vez que o cliente mandar mensagens
                
                Socket s = ss.accept(); // ele aceita a mensagem e deixa outra em espera 
                Scanner leitor = new Scanner(s.getInputStream()); // String recebe o conteudo da linha

               while (leitor.hasNext()) { // while usado para pegar proxima linha
                    
                   valores = leitor.nextLine();
                   
                   System.out.println(valores);
                   envia_Servidor_Resultado(valores);
                   
                }
                
                s.close();
            }

    }
     
      
     public void envia_Servidor_Resultado(String resultado) throws IOException{
        
        
        Socket socket1 = null;

        String host1 = "127.0.0.1";

        socket1 = new Socket(host1, 7777);
          
        PrintWriter escritor1 = new PrintWriter(socket1.getOutputStream());

        escritor1.println(resultado);
        escritor1.flush();
        escritor1.close();
        
        System.out.println("Resultado enviado para o Middleware!");
            
            
        }
     
     
     
    
     
     public static void main(String[] args) throws IOException {
        
         new Server1();
         
    }
    
}
